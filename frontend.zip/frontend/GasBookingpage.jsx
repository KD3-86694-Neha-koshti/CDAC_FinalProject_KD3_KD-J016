import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import { toast } from "react-toastify";

function GasBookingPage() {
  const [formData, setFormData] = useState({
    customerName: "",
    cylinderType: "",
    paymentMethod: "",
    userID: "",
  });

  const [bookingSuccess, setBookingSuccess] = useState(false); // ✅ Show success screen
  const [bookingDetails, setBookingDetails] = useState(null); // ✅ Store booking data

  useEffect(() => {
    const userId = sessionStorage.getItem("userId");
    if (!userId) {
      toast.error("No User ID Found. Please Login Again.");
    } else {
      setFormData((prev) => ({ ...prev, userID: userId }));
    }
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleBooking = async (e) => {
    e.preventDefault();

    if (!formData.customerName || !formData.cylinderType || !formData.paymentMethod) {
      toast.warn("Please fill all fields before booking.");
      return;
    }

    const bookingData = {
      userID: formData.userID,
      customerName: formData.customerName,
      cylinderType: formData.cylinderType.toUpperCase(),
      paymentStatus: formData.paymentMethod,
      status: "PENDING",
    };

    console.log("📢 Sending Booking Data:", bookingData);

    try {
      const response = await fetch("http://localhost:8080/booking", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(bookingData),
      });

      if (response.ok) {
        const responseData = await response.json();
        toast.success("✅ Cylinder Booking Successful!");
        setBookingDetails(responseData); // ✅ Store response for success screen
        setBookingSuccess(true); // ✅ Show success screen
      } else {
        toast.error("❌ Booking Failed. Try again.");
      }
    } catch (error) {
      console.error("❌ Booking Error:", error);
      toast.error("Server error. Please try again later.");
    }
  };

  if (bookingSuccess && bookingDetails) {
    return (
      <div className="container mt-5 text-center">
        <h2 className="text-success">✅ Booking Confirmed!</h2>
        <p>Your gas cylinder has been successfully booked.</p>
        <div className="card mt-3 p-3">
          <h4>Booking Details:</h4>
          <p><strong>Customer Name:</strong> {bookingDetails.customerName}</p>
          <p><strong>Cylinder Type:</strong> {bookingDetails.cylinderType}</p>
          <p><strong>Payment Method:</strong> {bookingDetails.paymentStatus}</p>
          <p><strong>Status:</strong> {bookingDetails.status}</p>
        </div>
        <a href="/user-dashboard" className="btn btn-primary mt-3">Go to Dashboard</a>
      </div>
    );
  }

  return (
    <div>
      <Navbar currentTab="user-dashboard" />
      <div className="container mt-5">
        <h2 className="text-center">Book Gas Cylinder</h2>
        <form className="mt-4" onSubmit={handleBooking}>
          <div className="mb-3">
            <label htmlFor="customerName" className="form-label">Customer Name</label>
            <input 
              type="text"
              className="form-control"
              id="customerName"
              name="customerName"
              placeholder="Enter your name"
              value={formData.customerName}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="cylinderType" className="form-label">Cylinder Type</label>
            <select
              className="form-select"
              id="cylinderType"
              name="cylinderType"
              value={formData.cylinderType}
              onChange={handleChange}
              required
            >
              <option value="">Select cylinder type</option>
              <option value="DOMESTIC">Domestic</option>
              <option value="COMMERCIAL">Commercial</option>
            </select>
          </div>

          <div className="mb-3">
            <label htmlFor="paymentMethod" className="form-label">Payment Method</label>
            <select
              className="form-select"
              id="paymentMethod"
              name="paymentMethod"
              value={formData.paymentMethod}
              onChange={handleChange}
              required
            >
              <option value="">Select payment method</option>
              <option value="CREDIT_CARD">Credit Card</option>
              <option value="DEBIT_CARD">Debit Card</option>
              <option value="NET_BANKING">Net Banking</option>
              <option value="CASH_ON_DELIVERY">Cash on Delivery</option>
            </select>
          </div>

          <button type="submit" className="btn btn-success me-3">Book Now</button>
          <button type="reset" className="btn btn-secondary">Reset</button>
        </form>

        <div className="mt-4 text-center">
          <a href="/user-dashboard" className="btn btn-link">Back to Dashboard</a>
        </div>
      </div>
    </div>
  );
}

export default GasBookingPage;
