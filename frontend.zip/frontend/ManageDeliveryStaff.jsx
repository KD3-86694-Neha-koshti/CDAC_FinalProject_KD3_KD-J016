import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import {
  getAllDeliveryStaff,
  registerUser,
  updateUserInfo,
  updateUserStatus, // ✅ Import for updating status
} from "../services/apiservice";

const ManageDeliveryStaff = () => {
  const [staff, setStaff] = useState([]);
  const [newStaff, setNewStaff] = useState({
    id: "", 
    fullName: "",
    email: "",
    mobileNo: "",
  });

  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchStaff();
  }, []);

  // ✅ Fetch All Delivery Staff
  const fetchStaff = async () => {
    try {
      const data = await getAllDeliveryStaff();
      setStaff(data);
    } catch (error) {
      toast.error("Failed to fetch delivery staff.");
    }
  };

  // ✅ Handle Input Change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewStaff({ ...newStaff, [name]: value });
  };

  // ✅ Add New Delivery Staff
  const handleAddStaff = async () => {
    if (!newStaff.fullName || !newStaff.email || !newStaff.mobileNo) {
      toast.warn("Please fill out all fields.");
      return;
    }

    try {
      console.log("🟢 Adding New Staff:", newStaff);

      await registerUser({
        fullName: newStaff.fullName,
        email: newStaff.email,
        mobileNo: newStaff.mobileNo,
        password: newStaff.email, // ✅ Email is used as the password
        address: "Update Once Logged In", // ✅ Default address
        role: "DELEVRYAGENT", // ✅ Kept role as "DELEVRYAGENT"
        status: "ACTIVE"
      });

      toast.success("✅ Delivery Staff Added Successfully!");
      setNewStaff({ id: "", fullName: "", email: "", mobileNo: "" });
      fetchStaff(); 
    } catch (error) {
      console.error("❌ Error adding staff:", error);
      toast.error("Failed to add staff.");
    }
  };

  // ✅ Update Existing Staff
  const handleUpdateStaff = async () => {
    if (!editingId || !newStaff.fullName || !newStaff.email || !newStaff.mobileNo) {
      toast.warn("Please fill out all fields.");
      return;
    }

    try {
      console.log(`🔄 Updating staff ID: ${editingId} with data:`, newStaff);

      await updateUserInfo(editingId, {
        id: editingId,
        fullName: newStaff.fullName,
        email: newStaff.email,
        mobileNo: newStaff.mobileNo,
        role: "DELEVRYAGENT" 
      });

      toast.success("✅ Delivery Staff Updated Successfully!");
      setNewStaff({ id: "", fullName: "", email: "", mobileNo: "" });
      setEditingId(null);
      fetchStaff();
    } catch (error) {
      console.error("❌ Error updating staff:", error);
      toast.error("Failed to update staff.");
    }
  };

  // ✅ Toggle Active/Inactive Status
  const handleToggleStatus = async (id, currentStatus) => {
    const newStatus = currentStatus === "ACTIVE" ? "INACTIVE" : "ACTIVE";

    try {
      console.log(`🔄 Changing status of staff ID: ${id} to ${newStatus}`);

      await updateUserStatus(id, newStatus); // ✅ Calls @PutMapping("/update-status/{id}")
      toast.success(`✅ Staff is now ${newStatus}`);
      fetchStaff(); // Refresh the list after update
    } catch (error) {
      console.error("❌ Error updating status:", error);
      toast.error("Failed to update staff status.");
    }
  };

  // ✅ Set staff data in form for editing
  const handleEditStaff = (staffMember) => {
    console.log("✏️ Editing Staff:", staffMember);

    setNewStaff({
      id: staffMember.id, 
      fullName: staffMember.fullName,
      email: staffMember.email,
      mobileNo: staffMember.mobileNo,
    });
    setEditingId(staffMember.id);
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h2>Manage Delivery Staff</h2>

      {/* Add & Update Form */}
      <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
        <input
          type="text"
          name="fullName"
          value={newStaff.fullName}
          placeholder="Full Name"
          onChange={handleInputChange}
          style={inputStyle}
        />
        <input
          type="email"
          name="email"
          value={newStaff.email}
          placeholder="Email"
          onChange={handleInputChange}
          style={inputStyle}
        />
        <input
          type="text"
          name="mobileNo"
          value={newStaff.mobileNo}
          placeholder="Mobile"
          onChange={handleInputChange}
          style={inputStyle}
        />
        {editingId ? (
          <button style={updateButtonStyle} onClick={handleUpdateStaff}>
            Update
          </button>
        ) : (
          <button style={addButtonStyle} onClick={handleAddStaff}>
            Add
          </button>
        )}
      </div>

      {/* Delivery Staff Table */}
      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
        <thead>
          <tr style={{ backgroundColor: "#003366", color: "white" }}>
            <th style={thStyle}>ID</th>
            <th style={thStyle}>Name</th>
            <th style={thStyle}>Email</th>
            <th style={thStyle}>Mobile</th>
            <th style={thStyle}>Status</th>
            <th style={thStyle}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {staff.map((s, index) => (
            <tr key={index} style={{ backgroundColor: index % 2 === 0 ? "#f9f9f9" : "white" }}>
              <td style={tdStyle}>{s.id}</td>
              <td style={tdStyle}>{s.fullName}</td>
              <td style={tdStyle}>{s.email}</td>
              <td style={tdStyle}>{s.mobileNo}</td>
              <td style={tdStyle}>{s.status}</td>
              <td style={tdStyle}>
                <button style={editButtonStyle} onClick={() => handleEditStaff(s)}>
                  Edit
                </button>
                <button
                  style={s.status === "ACTIVE" ? deactivateButtonStyle : activateButtonStyle}
                  onClick={() => handleToggleStatus(s.id, s.status)}
                >
                  {s.status === "ACTIVE" ? "Deactivate" : "Activate"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

// ✅ Styles
const thStyle = { padding: "10px", border: "1px solid #ccc", textAlign: "left" };
const tdStyle = { padding: "10px", border: "1px solid #ccc" };
const inputStyle = { padding: "5px", width: "200px", boxSizing: "border-box" };

const addButtonStyle = {
  padding: "5px 10px",
  backgroundColor: "green",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

const updateButtonStyle = {
  padding: "5px 10px",
  backgroundColor: "orange",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

const editButtonStyle = {
  padding: "5px 10px",
  backgroundColor: "blue",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

const activateButtonStyle = { ...editButtonStyle, backgroundColor: "green" };
const deactivateButtonStyle = { ...editButtonStyle, backgroundColor: "red" };

export default ManageDeliveryStaff;
