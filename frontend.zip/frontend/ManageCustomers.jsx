import React, { useState, useEffect } from "react";
import axios from "axios";

const API_BASE_URL = "http://localhost:8080"; // ✅ Update with your backend URL

const ManageCustomers = () => {
  const [customers, setCustomers] = useState([]);

  // ✅ Fetch Customers from API
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/getallcustomers`);
        setCustomers(response.data); // ✅ Update state with fetched customers
      } catch (error) {
        console.error("Error fetching customers:", error);
        setCustomers([]); // ✅ Handle errors gracefully
      }
    };

    fetchCustomers();
  }, []);

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h2>Manage Customers</h2>
      {customers.length === 0 ? (
        <p>No customers found.</p>
      ) : (
        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
          <thead>
            <tr style={{ backgroundColor: "#003366", color: "white" }}>
              <th style={thStyle}>Customer Id</th>
              <th style={thStyle}>Customer Name</th>
              <th style={thStyle}>Email</th>
              <th style={thStyle}>Mobile Number</th>
              <th style={thStyle}>Status</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((customer, index) => (
              <tr key={customer.id} style={{ backgroundColor: index % 2 === 0 ? "#f9f9f9" : "white" }}>
                <td style={tdStyle}>{customer.id}</td>
                <td style={tdStyle}>{customer.fullName}</td>
                <td style={tdStyle}>{customer.email}</td>
                <td style={tdStyle}>{customer.mobileNo}</td>
                <td style={tdStyle}>
                  <span
                    style={{
                      padding: "5px 10px",
                      color: "white",
                      borderRadius: "5px",
                      backgroundColor: customer.status === "ACTIVE" ? "green" : "red",
                    }}
                  >
                    {customer.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

// ✅ Table Header Style
const thStyle = {
  padding: "10px",
  border: "1px solid #ccc",
  textAlign: "left",
};

// ✅ Table Data Style
const tdStyle = {
  padding: "10px",
  border: "1px solid #ccc",
};

export default ManageCustomers;
