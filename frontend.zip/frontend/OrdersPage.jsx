import React, { useState, useEffect } from "react";
import axios from "axios";
import Navbar from "../components/Navbar";
import { toast } from "react-toastify";

const API_BASE_URL = "http://localhost:8080"; // ✅ Backend URL

function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const userId = sessionStorage.getItem("userId"); // ✅ Retrieve userId from session storage

    if (!userId) {
      setError("User not logged in. Please log in.");
      toast.error("User not logged in.");
      return;
    }

    axios
      .get(`${API_BASE_URL}/booking/user/${userId}`) // ✅ Fetch bookings for the logged-in user
      .then((response) => {
        console.log("User Bookings:", response.data);
        setOrders(response.data);
      })
      .catch((err) => {
        console.error("Error fetching orders:", err);
        setError("Failed to load orders.");
      });
  }, []);

  return (
    <div>
      <Navbar />
      <div className="container mt-5">
        <h2 className="text-center mb-4">Your Orders</h2>

        {error && <p className="text-danger text-center">{error}</p>}

        <table className="table table-bordered text-center">
          <thead className="table-light">
            <tr>
              <th>Booking ID</th> {/* ✅ From "id" */}
              <th>Cylinder Type</th> {/* ✅ From "cylinderType" */}
              <th>Payment Status</th> {/* ✅ From "paymentStatus" (Replaced Date) */}
              <th>Delivery Status</th> {/* ✅ From "status" */}
            </tr>
          </thead>
          <tbody>
            {orders.length > 0 ? (
              orders.map((order) => (
                <tr key={order.id}>
                  <td>{order.id}</td>
                  <td>{order.cylinderType}</td>
                  <td>
                    <span
                      className={`badge ${
                        order.paymentStatus.includes("Success") ? "bg-success" : "bg-danger"
                      }`}
                    >
                      {order.paymentStatus}
                    </span>
                  </td>
                  <td>
                    <span
                      className={`badge ${
                        order.status === "DELIVERED" ? "bg-success" : "bg-warning"
                      }`}
                    >
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" className="text-center">No orders found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default OrdersPage;
