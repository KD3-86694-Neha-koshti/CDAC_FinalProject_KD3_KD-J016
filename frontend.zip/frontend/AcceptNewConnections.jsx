import React, { useEffect, useState } from "react";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const API_BASE_URL = "http://localhost:8080"; // Replace with actual backend URL

const AcceptNewConnections = () => {
  const [customers, setCustomers] = useState([]);

  // 🔹 Fetch customers when the component loads
  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/getcustomerinfo`);
      setCustomers(response.data);
    } catch (error) {
      console.error("Error fetching customers:", error);
      toast.error("Failed to load customer data");
    }
  };

  // 🔹 Update user status (ACTIVE / INACTIVE)
  const updateStatus = async (id, newStatus) => {
    try {
      console.log(`Updating user ${id} to ${newStatus}`);

      await axios.put(`${API_BASE_URL}/update-status/${id}`, null, {
        params: { status: newStatus },
      });

      toast.success(`User ID ${id} updated to ${newStatus}`);
      fetchCustomers(); // Refresh list after update
    } catch (error) {
      console.error("Error updating status:", error);
      toast.error("Failed to update status");
    }
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      {/* Header */}
      <header style={{ backgroundColor: "#003366", color: "white", padding: "10px" }}>
        <h1 style={{ margin: 0 }}>Admin Dashboard - Gas Booking System</h1>
        <h2 style={{ margin: "10px 0" }}>Accept New Connections</h2>
      </header>

      {/* Table */}
      <table
        style={{
          width: "100%",
          marginTop: "20px",
          borderCollapse: "collapse",
          textAlign: "left",
          fontSize: "16px",
        }}
      >
        <thead>
          <tr>
            <th style={tableHeaderStyle}>Customer ID</th>
            <th style={tableHeaderStyle}>Customer Name</th>
            <th style={tableHeaderStyle}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((customer) => (
            <tr key={customer.id}>
              <td style={tableCellStyle}>{customer.id}</td>
              <td style={tableCellStyle}>{customer.fullName}</td>
              <td style={tableCellStyle}>
                <button
                  style={{
                    ...statusButtonStyle,
                    backgroundColor: customer.status === "ACTIVE" ? "green" : "gray",
                  }}
                  disabled={customer.status === "ACTIVE"}
                  onClick={() => updateStatus(customer.id, "ACTIVE")}
                >
                  Accept
                </button>
                <button
                  style={{
                    ...statusButtonStyle,
                    backgroundColor: customer.status === "INACTIVE" ? "red" : "gray",
                  }}
                  disabled={customer.status === "INACTIVE"}
                  onClick={() => updateStatus(customer.id, "INACTIVE")}
                >
                  Reject
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <ToastContainer position="top-right" autoClose={3000} hideProgressBar />
    </div>
  );
};

// Styles
const tableHeaderStyle = {
  backgroundColor: "#003366",
  color: "white",
  padding: "10px",
  border: "1px solid #ccc",
};

const tableCellStyle = {
  padding: "10px",
  border: "1px solid #ccc",
};

const statusButtonStyle = {
  padding: "5px 10px",
  marginRight: "5px",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

export default AcceptNewConnections;
