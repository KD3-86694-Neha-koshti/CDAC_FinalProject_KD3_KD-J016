import React from "react";

const ViewBookings = () => {
  const hasUnpaidBookings = false; // Set to false to show "Payment Successful!" (you can change this for testing)

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <header style={{ backgroundColor: "#003366", color: "white", padding: "10px" }}>
        <h1 style={{ margin: 0 }}>Gas Booking System</h1>
      </header>

      {/* Payment Status Section */}
      <div
        style={{
          marginTop: "40px", // Add some space from the header
          fontSize: "24px",
          fontWeight: "bold",
          color: "#003366", // Adjust text color
          textAlign: "center", // Center the text horizontally
        }}
      >
        {hasUnpaidBookings ? (
          "No Unpaid User, Will Inform you in case"
        ) : (
          "Payment Successful!"
        )}
      </div>

      {/* Additional Content Below */}
      <div style={{ marginTop: "20px", textAlign: "center", color: "#555" }}>
        {/* You can add more content here below the message */}
        <p>Your booking process is complete.</p>
      </div>
    </div>
  );
};

export default ViewBookings;
