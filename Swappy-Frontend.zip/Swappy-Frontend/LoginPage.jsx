import React, { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { gsap } from "gsap";
import "react-toastify/dist/ReactToastify.css";
import "../styles/AnimatedSVG.css";
import { loginUser } from "../services/apiservice";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  // **Use Refs for Animations**
  const armLRef = useRef(null);
  const armRRef = useRef(null);

  useEffect(() => {
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");

    if (!emailInput || !passwordInput) {
      console.warn("Email or Password input not found in DOM");
      return;
    }

    // Function to cover eyes
    const coverEyes = () => {
      gsap.to(armLRef.current, { x: -93, y: 2, rotation: 0, duration: 0.4 });
      gsap.to(armRRef.current, { x: -93, y: 2, rotation: 0, duration: 0.4 });
    };

    // Function to uncover eyes
    const uncoverEyes = () => {
      gsap.to(armLRef.current, { x: -93, y: 220, rotation: 105, duration: 1.2 });
      gsap.to(armRRef.current, { x: -93, y: 220, rotation: -105, duration: 1.2 });
    };

    coverEyes();

    emailInput.addEventListener("focus", uncoverEyes);
    passwordInput.addEventListener("focus", coverEyes);
    passwordInput.addEventListener("blur", uncoverEyes);

    return () => {
      emailInput.removeEventListener("focus", uncoverEyes);
      passwordInput.removeEventListener("focus", coverEyes);
      passwordInput.removeEventListener("blur", uncoverEyes);
    };
  }, []);

  const onLogin = async () => {
    if (email.trim() === "") {
      toast.warn("Please enter email");
      return;
    }
    if (password.trim() === "") {
      toast.warn("Please enter password");
      return;
    }

    try {
      const result = await loginUser(email, password);
      console.log("Login Response:", result); // ✅ Debugging log to check API response

      if (result && result.email) {
        const userStatus = result.status ? result.status.toUpperCase() : "UNKNOWN"; // ✅ Avoid case sensitivity issues

        if (userStatus === "ACTIVE") {
          sessionStorage.setItem("userId", result.id);
          sessionStorage.setItem("email", result.email);
          sessionStorage.setItem("role", result.role);
          sessionStorage.setItem("status", result.status);

          toast.success("Login Successful!");

          if (result.role === "ADMIN") {
            navigate("/admin-dashboard");
          } else if (result.role === "CUSTOMER") {
            navigate("/user-dashboard");
          } else if (result.role === "DELEVRYAGENT") {
            navigate("/delivery-dashboard");
          } else {
            toast.error("Invalid Role. Contact Support.");
          }
        } else if (userStatus === "INACTIVE") {
          console.warn("User is INACTIVE. Blocking login."); // ✅ Debugging log

          // **❌ Clear any stored session before blocking login**
          sessionStorage.clear();

          // ✅ **Show toast and return early to prevent login**
          toast.error("You have been blocked! Contact admin for access.");
          return; // 🚨 Stops further execution
        } else {
          console.error("Unexpected status:", userStatus);
          toast.error("Unknown user status. Contact support.");
          return;
        }
      } else {
        toast.error(result.error || "Invalid Credentials");
      }
    } catch (error) {
      console.error("Login Error:", error);
      toast.error("An error occurred while logging in.");
    }
  };

  return (
    <div className="login-page">
      <div className="container py-5">
        <div className="text-center mb-4">
          <div className="svgContainer">
            <svg className="mySVG" viewBox="0 0 200 200">
              <circle cx="100" cy="100" r="100" fill="#a9ddf3" />
              <g className="body">
                <path fill="#FFFFFF" d="M193.3,135.9c-5.8-8.4-15.5-13.9-26.5-13.9H151V72c0-27.6-22.4-50-50-50S51,44.4,51,72v50H32.1 c-10.6,0-20,5.1-25.8,13l0,78h187L193.3,135.9z" />
              </g>
              <g className="armL" ref={armLRef}>
                <path fill="#ddf1fa" stroke="#3a5e77" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M121.3 97.4L111 58.7l38.8-10.4 20 36.1z" />
              </g>
              <g className="armR" ref={armRRef}>
                <path fill="#ddf1fa" stroke="#3a5e77" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M265.4 97.3l10.4-38.6-38.9-10.5-20 36.1z" />
              </g>
            </svg>
          </div>
        </div>

        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="card shadow p-4 login-card">
              <form>
                <div className="mb-4">
                  <label htmlFor="email" className="form-label fw-bold">Email</label>
                  <input id="email" type="text" className="form-control" placeholder="Enter your Email" value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className="mb-4">
                  <label htmlFor="password" className="form-label fw-bold">Password</label>
                  <div className="position-relative">
                    <input id="password" type={showPassword ? "text" : "password"} className="form-control pe-5" placeholder="Enter your Password" value={password} onChange={(e) => setPassword(e.target.value)} />
                    <i className={showPassword ? "bi bi-eye-slash" : "bi bi-eye"} style={{ position: "absolute", right: "10px", top: "50%", transform: "translateY(-50%)", cursor: "pointer", fontSize: "1.2rem", color: "#6c757d" }} onClick={() => setShowPassword(!showPassword)}></i>
                  </div>
                </div>
                <button type="button" onClick={onLogin} className="btn btn-primary w-100 mb-3">Login</button>
                <div className="text-center">
                  <p>Don't have an account? <Link to="/register" className="text-decoration-none text-primary">Register here</Link></p>
                  <p>Forget password? <Link to="/forgetpasswd" className="text-decoration-none text-primary">Forget Password</Link></p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
