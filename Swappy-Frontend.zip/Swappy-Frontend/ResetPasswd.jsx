import React, { useState } from 'react';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import { resetPassword } from '../services/apiservice';

function ResetPassword() {
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newConfirmPassword, setNewConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const navigate = useNavigate();

  const handleResetPassword = async (e) => {
    e.preventDefault();

    if (!email) {
      toast.warn('Please enter your email address');
      return;
    } else if (!newPassword) {
      toast.warn('Please enter a new password');
      return;
    } else if (!newConfirmPassword) {
      toast.warn('Please confirm your new password');
      return;
    }

    if (newPassword !== newConfirmPassword) {
      toast.error('Passwords do not match!');
      return;
    }

    try {
      const response = await resetPassword(email, newPassword);
      if (response.status === 200) {
        toast.success('✅ Password updated successfully! Redirecting to Login...', {
          position: 'top-right',
        });

        setTimeout(() => {
          navigate('/login'); // Redirect to Login page
        }, 2000);
      }
    } catch (error) {
      toast.error('❌ Failed to update password. Please try again.');
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4 text-primary fw-bold">Reset Password</h2>

      <div className="row justify-content-center">
        <div className="col-md-6">
          <form onSubmit={handleResetPassword}>
            {/* Email */}
            <div className="mb-3">
              <label className="form-label fw-bold">Email</label>
              <input
                type="email"
                className="form-control"
                placeholder="Enter your Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            {/* New Password */}
            <div className="mb-3">
              <label className="form-label fw-bold">New Password</label>
              <div className="position-relative">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  className="form-control pe-5"
                  placeholder="Enter new password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                />
                <i
                  className={showNewPassword ? 'bi bi-eye-slash' : 'bi bi-eye'}
                  style={{
                    position: 'absolute',
                    right: '10px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    cursor: 'pointer',
                    fontSize: '1.2rem',
                    color: '#6c757d',
                  }}
                  onClick={() => setShowNewPassword(!showNewPassword)}
                ></i>
              </div>
            </div>

            {/* Confirm Password */}
            <div className="mb-3">
              <label className="form-label fw-bold">Confirm Password</label>
              <div className="position-relative">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  className="form-control pe-5"
                  placeholder="Confirm new password"
                  value={newConfirmPassword}
                  onChange={(e) => setNewConfirmPassword(e.target.value)}
                  required
                />
                <i
                  className={showConfirmPassword ? 'bi bi-eye-slash' : 'bi bi-eye'}
                  style={{
                    position: 'absolute',
                    right: '10px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    cursor: 'pointer',
                    fontSize: '1.2rem',
                    color: '#6c757d',
                  }}
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                ></i>
              </div>
            </div>

            {/* Update Password Button */}
            <button type="submit" className="btn btn-success w-100 mt-2">
              Update Password
            </button>

            {/* Back to Login Button */}
            <button
              type="button"
              className="btn btn-outline-primary w-100 mt-3"
              onClick={() => navigate('/login')}
            >
              Back to Login
            </button>
          </form>
        </div>
      </div>

      <ToastContainer position="top-right" autoClose={3000} hideProgressBar />
    </div>
  );
}

export default ResetPassword;
