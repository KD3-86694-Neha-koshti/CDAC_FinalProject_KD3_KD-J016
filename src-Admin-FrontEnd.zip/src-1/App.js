// Import required libraries
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

// Components
import HomePage from "./components/HomePage";
import SignUpPage from "./components/SignUpPage";
import LoginPage from "./components/LoginPage";
import ResetPasswd from './components/ResetPasswd';
import AdminDashboard from "./components/AdminDashboard";
import UserDashboard from "./components/UserDashboard";
import DeliveryDashboard from "./components/DeliveryDashboard";
import PaymentStatus from "./components/PaymentStatus"; // Import PaymentStatus

// Admin Dashboard Sub-Components
import ManageCustomers from "./components/ManageCustomers";
import ManageDeliveryStaff from "./components/ManageDeliveryStaff";
import AcceptNewConnections from "./components/AcceptNewConnections";
import ManageGasCylinder from "./components/ManageGasCylinder";
import ViewBookings from "./components/ViewBookings";

function App() {
  return (
    <Router>
      <div>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<HomePage />} />
          <Route path="/signup" element={<SignUpPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<SignUpPage />} />
          <Route path="/forgetpasswd" element={<ResetPasswd />} />

          {/* User Dashboards */}
          <Route path="/admin-dashboard" element={<AdminDashboard />}>
            <Route path="manage-customers" element={<ManageCustomers />} />
            <Route path="manage-delivery-staff" element={<ManageDeliveryStaff />} />
            <Route path="accept-new-connections" element={<AcceptNewConnections />} />
            <Route path="manage-gas-cylinder" element={<ManageGasCylinder />} />
            <Route path="view-bookings" element={<ViewBookings />} />
            <Route path="payment-status" element={<PaymentStatus />} />
          </Route>
          <Route path="/user-dashboard" element={<UserDashboard />} />
          <Route path="/delivery-dashboard" element={<DeliveryDashboard />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
