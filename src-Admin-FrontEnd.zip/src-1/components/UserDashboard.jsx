// UserDashboard.js - Combined and Improved
import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";

function UserDashboard() {
  const bookingHistory = [
    { id: 1, date: "2023-12-01", status: "Completed" },
    { id: 2, date: "2023-12-10", status: "Pending" },
  ];

  return (
    <div className="container py-5">
      <h2 className="text-center mb-4 text-primary fw-bold">User Dashboard</h2>

      <div className="mb-5">
        <h3 className="fw-bold">Book Gas Cylinder</h3>
        <button className="btn btn-primary">Book Now</button>
      </div>

      <div className="mb-5">
        <h3 className="fw-bold">Booking History</h3>
        <ul className="list-group">
          {bookingHistory.map((booking) => (
            <li key={booking.id} className="list-group-item">
              Date: {booking.date} - Status: {booking.status}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default UserDashboard;
