import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../styles/LoginPage.css'; // Add a CSS file for custom styles

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const adminCredentials = { email: "admin", password: "admin" };
  const deliveryCredentials = { email: "delivery", password: "delivery" };
  const userCredentials = { email: "user", password: "user" };

  const navigate = useNavigate();

  const onLogin = () => {
    if (email.length === 0) {
      toast.warn('Please enter email');
    } else if (password.length === 0) {
      toast.warn('Please enter password');
    } else if (email === adminCredentials.email && password === adminCredentials.password) {
      toast.success("Welcome Admin");
      navigate('/admin-dashboard');
    } else if (email === deliveryCredentials.email && password === deliveryCredentials.password) {
      toast.success("Welcome Delivery Staff");
      navigate('/delivery-dashboard');
    } else if (email === userCredentials.email && password === userCredentials.password) {
      toast.success("Welcome User");
      navigate('/user-dashboard');
    } else {
      toast.error("Invalid credentials");
    }
  };

  return (
    <div className="login-page">
      <div className="container py-5">
        <div className="text-center mb-4">
          <img
            src={require('../imagesss/logologin.jpg')}
            width={150}
            height={100}
            alt="Login Logo"
            className="mb-3"
          />
          <h2 className="header text-primary fw-bold">Online Gas Booking</h2>
          <h3 className="header text-secondary">Login</h3>
        </div>

        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="card shadow p-4 login-card">
              <form>
                <div className="mb-4">
                  <label htmlFor="email" className="form-label fw-bold">
                    Email
                  </label>
                  <input
                    onChange={(e) => setEmail(e.target.value)}
                    type="email"
                    className="form-control"
                    placeholder="Enter your Email"
                    value={email}
                  />
                </div>
                <div className="mb-4">
                  <label htmlFor="password" className="form-label fw-bold">
                    Password
                  </label>
                  <input
                    onChange={(e) => setPassword(e.target.value)}
                    type="password"
                    className="form-control"
                    placeholder="Enter your Password"
                    value={password}
                  />
                </div>
                <button
                  type="button"
                  onClick={onLogin}
                  className="btn btn-primary w-100 mb-3"
                >
                  Login
                </button>
                <div className="text-center">
                  <p>
                    Don't have an account?{" "}
                    <Link to="/register" className="text-decoration-none text-primary">
                      Register here
                    </Link>
                  </p>
                  <p>
                    Forget password?{" "}
                    <Link to="/forgetpasswd" className="text-decoration-none text-primary">
                      Forget Password
                    </Link>
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
