package com.blogs.dto;
import com.blogs.pojos.Booking.CylinderType;
import com.blogs.pojos.Booking.Status;

public class BookingRespDto {
	
	private Long userID;
	private boolean paymentStatus;
	private Status status;
	private CylinderType cylinderType;
}
