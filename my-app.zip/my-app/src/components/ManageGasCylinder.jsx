import React from "react";

const ManageGasCylinder = () => {
  return (
    <div>
      <h2>Manage Gas Cylinder Page</h2>
      <table border="1" style={{ width: "100%", borderCollapse: "collapse", margin: "20px 0" }}>
        <thead>
          <tr style={{ backgroundColor: "#f2f2f2" }}>
            <th>Cylinder ID</th>
            <th>Cylinder Type</th>
            <th>Quantity</th>
            <th>Available</th>
            <th>Not Available</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>10101</td>
            <td>Domestic</td>
            <td>100</td>
            <td>50</td>
            <td>50</td>
            <td>
              <button style={actionButtonStyle}>Filled Cylinder</button>
            </td>
          </tr>
          <tr>
            <td>10102</td>
            <td>Commercial</td>
            <td>200</td>
            <td>0</td>
            <td>200</td>
            <td>
              <button style={{ ...actionButtonStyle, backgroundColor: "red" }}>Refill</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

const actionButtonStyle = {
  padding: "5px 10px",
  color: "white",
  backgroundColor: "green",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

export default ManageGasCylinder;
