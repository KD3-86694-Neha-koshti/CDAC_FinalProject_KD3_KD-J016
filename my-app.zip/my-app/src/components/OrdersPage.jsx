import React from 'react';
import Navbar from '../components/Navbar';

function OrdersPage() {
  return (
    <div>
      <Navbar />
      <div className="container mt-5">
        <h2 className="text-center mb-4">Orders</h2>
        <table className="table table-bordered text-center">
          <thead className="table-light">
            <tr>
              <th>Booking Id</th>
              <th>Cylinder Type</th>
              <th>Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>10101</td>
              <td>Domestics</td>
              <td>12-01-2024</td>
              <td>Delivered</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default OrdersPage;
