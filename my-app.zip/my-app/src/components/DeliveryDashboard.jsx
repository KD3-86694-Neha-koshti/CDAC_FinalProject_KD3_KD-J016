import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify"; // Import toast
import "react-toastify/dist/ReactToastify.css"; // Import styles

const Home = () => {
  const navigate = useNavigate();

  // Define showToast function inside the component
  const showToast = (message, type = "success") => {
    toast(message, { type, position: "top-right" });
  };

  const handleLogout = () => {
    showToast("Logged out successfully!", "success");
    navigate("/login");
  };

  return (
    <div className="container mt-4 colorful-page position-relative">
      <div className="d-flex justify-content-end mb-3">
        <button className="btn btn-danger btn-sm" onClick={handleLogout}>
          Logout
        </button>
      </div>
      <center>
        <h2 className="mb-4">Welcome to the Delivery Agent Dashboard</h2>
      </center>
      <div className="d-flex justify-content-center gap-3 mb-4">
        <Link to="/orders" className="btn btn-primary btn-lg">
          View Assigned Orders
        </Link>
        <Link to="/refill" className="btn btn-secondary btn-lg">
          Refill Gas Cylinder
        </Link>
      </div>

      {/* Add ToastContainer to display notifications */}
      <ToastContainer />
    </div>
  );
};

export default Home;
