import React, { useState } from "react";

const ManageDeliveryStaff = () => {
  const [staff, setStaff] = useState([
    { id: 10101, name: "Raju Bihari", email: "Raju@gmail.com", mobile: "9359472565" },
    { id: 10102, name: "Swapnil Karnatak", email: "swapnil@gmail.com", mobile: "25874125" },
  ]);

  const [newStaff, setNewStaff] = useState({ id: "", name: "", email: "", mobile: "" });

  // Handle input changes for new staff
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewStaff({ ...newStaff, [name]: value });
  };

  // Add new staff
  const handleAddStaff = () => {
    if (newStaff.id && newStaff.name && newStaff.email && newStaff.mobile) {
      setStaff([...staff, newStaff]);
      setNewStaff({ id: "", name: "", email: "", mobile: "" });
    } else {
      alert("Please fill out all fields!");
    }
  };

  // Delete staff
  const handleDeleteStaff = (id) => {
    setStaff(staff.filter((s) => s.id !== id));
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h2>Manage Delivery Staff</h2>
      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
        <thead>
          <tr style={{ backgroundColor: "#003366", color: "white" }}>
            <th style={thStyle}>Delivery Staff ID</th>
            <th style={thStyle}>Name</th>
            <th style={thStyle}>Email</th>
            <th style={thStyle}>Mobile</th>
            <th style={thStyle}>Actions</th>
          </tr>
        </thead>
        <tbody>
        <tr>
            <td style={tdStyle}>
              <input
                type="text"
                name="id"
                value={newStaff.id}
                placeholder="ID"
                onChange={handleInputChange}
                style={inputStyle}
              />
            </td>
            <td style={tdStyle}>
              <input
                type="text"
                name="name"
                value={newStaff.name}
                placeholder="Name"
                onChange={handleInputChange}
                style={inputStyle}
              />
            </td>
            <td style={tdStyle}>
              <input
                type="email"
                name="email"
                value={newStaff.email}
                placeholder="Email"
                onChange={handleInputChange}
                style={inputStyle}
              />
            </td>
            <td style={tdStyle}>
              <input
                type="text"
                name="mobile"
                value={newStaff.mobile}
                placeholder="Mobile"
                onChange={handleInputChange}
                style={inputStyle}
              />
            </td>
            <td style={tdStyle}>
              <button style={addButtonStyle} onClick={handleAddStaff}>
                Add
              </button>
            </td>
          </tr>
          {staff.map((s, index) => (
            <tr key={index} style={{ backgroundColor: index % 2 === 0 ? "#f9f9f9" : "white" }}>
              <td style={tdStyle}>{s.id}</td>
              <td style={tdStyle}>{s.name}</td>
              <td style={tdStyle}>{s.email}</td>
              <td style={tdStyle}>{s.mobile}</td>
              <td style={tdStyle}>
                <button style={updateButtonStyle}>Update</button>
                <button style={deleteButtonStyle} onClick={() => handleDeleteStaff(s.id)}>
                  DELETE
                </button>
              </td>
            </tr>
          ))}
          
        </tbody>
      </table>
    </div>
  );
};

const thStyle = {
  padding: "10px",
  border: "1px solid #ccc",
  textAlign: "left",
};

const tdStyle = {
  padding: "10px",
  border: "1px solid #ccc",
};

const inputStyle = {
  width: "100%",
  padding: "5px",
  boxSizing: "border-box",
};

const updateButtonStyle = {
  padding: "5px 10px",
  marginRight: "5px",
  backgroundColor: "orange",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

const deleteButtonStyle = {
  padding: "5px 10px",
  backgroundColor: "red",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

const addButtonStyle = {
  padding: "5px 10px",
  backgroundColor: "green",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

export default ManageDeliveryStaff;
