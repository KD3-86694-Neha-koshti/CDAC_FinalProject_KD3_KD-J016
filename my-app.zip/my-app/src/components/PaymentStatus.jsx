import React from "react";
import "../styles/PaymentStatus.css"; // Create a CSS file for custom styles

const PaymentStatus = () => {
  return (
    <div className="payment-status-container">
      <div className="status-card">
        <h1 className="status-title">Payment Status</h1>
        <p className="status-message text-success">Payment Successful!</p>
        <p className="status-details">
          No Unpaid User, Will Inform you in case
        </p>
      </div>
    </div>
  );
};

export default PaymentStatus;
