import Navbar from '../components/Navbar';

function GasBookingPage() {
    return (
        <div>
            <Navbar currentTab="user-dashboard" />
            <div className="container mt-5">
                <h2 className="text-center">Book Gas Cylinder</h2>
                <form className="mt-4">
                    <div className="mb-3">
                        <label htmlFor="customerNumber" className="form-label">Customer Number</label>
                        <input 
                            type="text" 
                            className="form-control" 
                            id="customerNumber" 
                            placeholder="Enter your customer number" 
                        />
                    </div>

                    <div className="mb-3">
                        <label htmlFor="cylinderType" className="form-label">Cylinder Type</label>
                        <select className="form-select" id="cylinderType">
                            <option value="">Select cylinder type</option>
                            <option value="domestic">Domestic</option>
                            <option value="commercial">Commercial</option>
                        </select>
                    </div>

                    <div className="mb-3">
                        <label htmlFor="paymentMethod" className="form-label">Payment Method</label>
                        <select className="form-select" id="paymentMethod">
                            <option value="">Select payment method</option>
                            <option value="creditCard">Credit Card</option>
                            <option value="debitCard">Debit Card</option>
                            <option value="netBanking">Net Banking</option>
                            <option value="cashOnDelivery">Cash on Delivery</option>
                        </select>
                    </div>

                    <button type="submit" className="btn btn-success me-3">Book Now</button>
                    <button type="reset" className="btn btn-secondary">Reset</button>
                </form>

                <div className="mt-4 text-center">
                    <a href="/user-dashboard" className="btn btn-link">Back to Dashboard</a>
                </div>
            </div>
        </div>
    );
}

export default GasBookingPage;
