import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { gsap } from "gsap";
import "../styles/AnimatedSVG.css"; // Add your custom styles here

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const adminCredentials = { email: "admin", password: "admin" };
  const deliveryCredentials = { email: "delivery", password: "delivery" };
  const userCredentials = { email: "user", password: "user" };

  const navigate = useNavigate();

  useEffect(() => {
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");

    // Function to close eyes
    const coverEyes = () => {
      gsap.to(".armL", { x: -93, y: 2, rotation: 0, duration: 0.4 });
      gsap.to(".armR", { x: -93, y: 2, rotation: 0, duration: 0.4 });
    };

    // Function to open eyes
    const uncoverEyes = () => {
      gsap.to(".armL", { x: -93, y: 220, rotation: 105, duration: 1.2 });
      gsap.to(".armR", { x: -93, y: 220, rotation: -105, duration: 1.2 });
    };

    // Initially close eyes on load
    coverEyes();

    // Event listeners for inputs
    emailInput.addEventListener("focus", uncoverEyes);
    passwordInput.addEventListener("focus", coverEyes);
    passwordInput.addEventListener("blur", uncoverEyes);

    return () => {
      emailInput.removeEventListener("focus", uncoverEyes);
      passwordInput.removeEventListener("focus", coverEyes);
      passwordInput.removeEventListener("blur", uncoverEyes);
    };
  }, []);

  const onLogin = () => {
    if (email.length === 0) {
      toast.warn("Please enter email");
    } else if (password.length === 0) {
      toast.warn("Please enter password");
    } else if (email === adminCredentials.email && password === adminCredentials.password) {
      toast.success("Welcome Admin");
      navigate("/admin-dashboard");
    } else if (email === deliveryCredentials.email && password === deliveryCredentials.password) {
      toast.success("Welcome Delivery Staff");
      navigate("/delivery-dashboard");
    } else if (email === userCredentials.email && password === userCredentials.password) {
      toast.success("Welcome User");
      navigate("/user-dashboard");
    } else {
      toast.error("Invalid credentials");
    }
  };

  return (
    <div className="login-page">
      <div className="container py-5">
        <div className="text-center mb-4">
          <div className="svgContainer">
            <svg
              className="mySVG"
              xmlns="http://www.w3.org/2000/svg"
              xmlnsXlink="http://www.w3.org/1999/xlink"
              viewBox="0 0 200 200"
            >
              <defs>
                <circle id="armMaskPath" cx="100" cy="100" r="100" />
              </defs>
              <clipPath id="armMask">
                <use xlinkHref="#armMaskPath" overflow="visible" />
              </clipPath>
              <circle cx="100" cy="100" r="100" fill="#a9ddf3" />
              <g className="body">
                <path
                  fill="#FFFFFF"
                  d="M193.3,135.9c-5.8-8.4-15.5-13.9-26.5-13.9H151V72c0-27.6-22.4-50-50-50S51,44.4,51,72v50H32.1 c-10.6,0-20,5.1-25.8,13l0,78h187L193.3,135.9z"
                />
                <path
                  fill="none"
                  stroke="#3A5E77"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M193.3,135.9 c-5.8-8.4-15.5-13.9-26.5-13.9H151V72c0-27.6-22.4-50-50-50S51,44.4,51,72v50H32.1c-10.6,0-20,5.1-25.8,13"
                />
              </g>
              <g className="armL">
                <path
                  fill="#ddf1fa"
                  stroke="#3a5e77"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2.5"
                  d="M121.3 97.4L111 58.7l38.8-10.4 20 36.1z"
                />
              </g>
              <g className="armR">
                <path
                  fill="#ddf1fa"
                  stroke="#3a5e77"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2.5"
                  d="M265.4 97.3l10.4-38.6-38.9-10.5-20 36.1z"
                />
              </g>
            </svg>
          </div>
          <h2 className="header text-primary fw-bold">Admin Dashboard Login</h2>
          <h3 className="header text-secondary">Welcome Back!</h3>
        </div>

        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="card shadow p-4 login-card">
              <form>
                <div className="mb-4">
                  <label htmlFor="email" className="form-label fw-bold">
                    Email
                  </label>
                  <input
                    id="email"
                    type="text"
                    className="form-control"
                    placeholder="Enter your Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="mb-4">
                  <label htmlFor="password" className="form-label fw-bold">
                    Password
                  </label>
                  <input
                    id="password"
                    type="password"
                    className="form-control"
                    placeholder="Enter your Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <button
                  type="button"
                  onClick={onLogin}
                  className="btn btn-primary w-100 mb-3"
                >
                  Login
                </button>
                <div className="text-center">
                  <p>
                    Don't have an account?{" "}
                    <Link to="/register" className="text-decoration-none text-primary">
                      Register here
                    </Link>
                  </p>
                  <p>
                    Forget password?{" "}
                    <Link to="/forgetpasswd" className="text-decoration-none text-primary">
                      Forget Password
                    </Link>
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
