// HomePage.js - Combined and Improved
import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";

function HomePage() {
  return (
    <div className="container-fluid bg-light text-dark py-5" style={{ minHeight: "100vh" }}>
      <header className="text-center mb-5">
        <h1 className="display-4 fw-bold">Welcome to Online Gas Booking System</h1>
        <p className="lead">Your one-stop solution for gas booking at your convenience.</p>
      </header>

      <div className="row justify-content-center text-center">
        <div className="col-lg-4 col-md-6 col-sm-12 mb-4">
          <div className="card shadow-lg border-0">
            <div className="card-body">
              <h5 className="card-title">New User?</h5>
              <p className="card-text">Sign up today to get started with hassle-free gas booking.</p>
              <a href="/signup" className="btn btn-primary">Sign Up</a>
            </div>
          </div>
        </div>

        <div className="col-lg-4 col-md-6 col-sm-12 mb-4">
          <div className="card shadow-lg border-0">
            <div className="card-body">
              <h5 className="card-title">Existing User?</h5>
              <p className="card-text">Log in to your account to manage your bookings.</p>
              <a href="/login" className="btn btn-secondary">Login</a>
            </div>
          </div>
        </div>
      </div>

      <footer className="text-center mt-5">
        <p className="text-muted">&copy; 2024 Online Gas Booking System. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default HomePage;
