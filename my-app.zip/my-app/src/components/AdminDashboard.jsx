import React from "react";
import { Outlet, Link } from "react-router-dom";
import "../styles/AdminDashboard.css";

const AdminDashboard = () => {
  return (
    <div className="container">
      {/* Header */}
      <header className="header">
        <h1>Admin Dashboard - Gas Booking System</h1>
      </header>

      {/* Navigation Bar */}
      <nav className="navbar">
        <Link to="manage-customers" className="nav-link">
          Manage Customers
        </Link>
        <Link to="manage-delivery-staff" className="nav-link">
          Manage Delivery Staff
        </Link>
        <Link to="payment-status" className="nav-link">
          Payment Status
        </Link>
        <Link to="view-bookings" className="nav-link">
          View Bookings
        </Link>
        <Link to="accept-new-connections" className="nav-link">
          Accept New Connections
        </Link>
        <Link to="manage-gas-cylinder" className="nav-link">
          Manage Gas Cylinder
        </Link>
      </nav>

      {/* Outlet for Nested Routes */}
      <div className="content">
        <Outlet />
      </div>
    </div>
  );
};

export default AdminDashboard;
