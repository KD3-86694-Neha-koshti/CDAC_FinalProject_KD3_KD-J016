// SignUpPage.js - Combined and Improved
import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";

function SignUpPage() {
  return (
    <div
      className="container py-5"
      style={{
        backgroundColor: "#f8f9fa",
        borderRadius: "10px",
        boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
      }}
    >
      <h2 className="text-center mb-4 text-primary fw-bold">Sign-Up</h2>
      <form>
        <div className="mb-3">
          <label className="form-label fw-bold">Full Name</label>
          <input
            type="text"
            className="form-control"
            placeholder="Enter your full name"
          />
        </div>
        <div className="mb-3">
          <label className="form-label fw-bold">Email Address</label>
          <input
            type="email"
            className="form-control"
            placeholder="Enter your email"
          />
        </div>
        <div className="mb-3">
          <label className="form-label fw-bold">Phone Number</label>
          <input
            type="tel"
            className="form-control"
            placeholder="Enter your phone number"
          />
        </div>
        <div className="mb-3">
          <label className="form-label fw-bold">Address</label>
          <input
            type="text"
            className="form-control"
            placeholder="Enter your address"
          />
        </div>
        <div className="mb-3">
          <label className="form-label fw-bold">Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="Enter your password"
          />
        </div>
        <div className="mb-3">
          <label className="form-label fw-bold">Confirm Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="Confirm your password"
          />
        </div>
        <button type="submit" className="btn btn-primary w-100 mt-3">
          Sign Up
        </button>
      </form>
      <footer className="text-center mt-4">
        <p className="text-muted">
          Already have an account? <a href="/login" className="text-primary">Login here</a>.
        </p>
      </footer>
    </div>
  );
}

export default SignUpPage;
