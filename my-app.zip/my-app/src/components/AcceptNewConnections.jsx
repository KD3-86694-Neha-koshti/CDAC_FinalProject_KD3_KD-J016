import React from "react";

const AcceptNewConnections = () => {
  // Hardcoded data for now
  const connectionRequests = [
    { requestId: "987452569586", customerId: "10101" },
    { requestId: "656458787878", customerId: "10102" },
  ];

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      {/* Header */}
      <header style={{ backgroundColor: "#003366", color: "white", padding: "10px" }}>
        <h1 style={{ margin: 0 }}>Admin Dashboard - Gas Booking System</h1>
        <h2 style={{ margin: "10px 0" }}>Accept New Connections</h2>
      </header>

      {/* Table */}
      <table
        style={{
          width: "100%",
          marginTop: "20px",
          borderCollapse: "collapse",
          textAlign: "left",
          fontSize: "16px",
        }}
      >
        <thead>
          <tr>
            <th style={tableHeaderStyle}>Request ID</th>
            <th style={tableHeaderStyle}>Customer ID</th>
            <th style={tableHeaderStyle}>Status</th>
          </tr>
        </thead>
        <tbody>
          {connectionRequests.map((request, index) => (
            <tr key={index}>
              <td style={tableCellStyle}>{request.requestId}</td>
              <td style={tableCellStyle}>{request.customerId}</td>
              <td style={tableCellStyle}>
                <button style={acceptButtonStyle}>Accept</button>
                <button style={rejectButtonStyle}>Reject</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

// Styles
const tableHeaderStyle = {
  backgroundColor: "#003366",
  color: "white",
  padding: "10px",
  border: "1px solid #ccc",
};

const tableCellStyle = {
  padding: "10px",
  border: "1px solid #ccc",
};

const acceptButtonStyle = {
  padding: "5px 10px",
  marginRight: "5px",
  backgroundColor: "green",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

const rejectButtonStyle = {
  padding: "5px 10px",
  backgroundColor: "red",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

export default AcceptNewConnections;
