import React from "react";

const ViewBookings = () => {
  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <header style={{ backgroundColor: "#003366", color: "white", padding: "10px" }}>
        <h1 style={{ margin: 0 }}>Admin Dashboard - Gas Booking System</h1>
      </header>

      <h2 style={{ marginTop: "20px" }}>View Booking History</h2>

      <table border="1" style={{ width: "100%", borderCollapse: "collapse", margin: "20px 0" }}>
        <thead>
          <tr style={{ backgroundColor: "#f2f2f2" }}>
            <th>Booking ID</th>
            <th>Cylinder Type</th>
            <th>Date</th>
            <th>Prices</th>
            <th>Status</th>
            <th>Payment</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>10010</td>
            <td>Domestic</td>
            <td>12-02-2024</td>
            <td>1000</td>
            <td>
              <span style={{ color: "green", fontWeight: "bold" }}>Delivered</span>
            </td>
            <td>
              <span style={{ color: "green", fontWeight: "bold" }}>Success</span>
            </td>
          </tr>
          <tr>
            <td>10010</td>
            <td>Commercial</td>
            <td>12-02-2024</td>
            <td>1500</td>
            <td>
              <span style={{ color: "red", fontWeight: "bold" }}>Not Delivered</span>
            </td>
            <td>
              <span style={{ color: "red", fontWeight: "bold" }}>Failed</span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default ViewBookings;
