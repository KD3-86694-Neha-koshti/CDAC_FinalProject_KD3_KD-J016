import React, { useState, useEffect } from "react";
import axios from "axios";

const ViewBookings = ({ role }) => {
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState("");

  // Fetch booking history based on user role
  useEffect(() => {
    const url = role === "admin" ? "/api/bookings" : "/api/bookings/user"; // Adjust API paths based on role

    // Mocking API response if backend is not yet available
    if (url === "/api/bookings") {
      setBookings([
        {
          bookingId: 1001,
          cylinderType: "Domestic",
          date: "2024-01-15T12:00:00Z",
          price: 1000,
          status: "Delivered",
          paymentStatus: "Success",
        },
        {
          bookingId: 1002,
          cylinderType: "Commercial",
          date: "2024-01-20T12:00:00Z",
          price: 1500,
          status: "Not Delivered",
          paymentStatus: "Failed",
        },
      ]);
    } else {
      setBookings([
        {
          bookingId: 1003,
          cylinderType: "Domestic",
          date: "2024-01-10T12:00:00Z",
          price: 1000,
          status: "Delivered",
          paymentStatus: "Success",
        },
      ]);
    }

    // Uncomment below to use real axios API call
    // axios
    //   .get(url)
    //   .then((response) => {
    //     setBookings(response.data);
    //   })
    //   .catch((err) => {
    //     setError("Failed to load booking data.");
    //     console.error("Error fetching bookings:", err);
    //   });
  }, [role]);

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <header style={{ backgroundColor: "#003366", color: "white", padding: "10px" }}>
        <h1 style={{ margin: 0 }}>Gas Booking System</h1>
      </header>

      <h2 style={{ marginTop: "20px" }}>
        {role === "admin" ? "All Booking History" : "Your Booking History"}
      </h2>

      {error && <p style={{ color: "red" }}>{error}</p>}

      <table border="1" style={{ width: "100%", borderCollapse: "collapse", margin: "20px 0" }}>
        <thead>
          <tr style={{ backgroundColor: "#f2f2f2" }}>
            <th>Booking ID</th>
            <th>Cylinder Type</th>
            <th>Date</th>
            <th>Price</th>
            <th>Status</th>
            <th>Payment</th>
          </tr>
        </thead>
        <tbody>
          {bookings.length > 0 ? (
            bookings.map((booking) => (
              <tr key={booking.bookingId}>
                <td>{booking.bookingId}</td>
                <td>{booking.cylinderType}</td>
                <td>{new Date(booking.date).toLocaleDateString()}</td>
                <td>{booking.price}</td>
                <td>
                  <span
                    style={{
                      color: booking.status === "Delivered" ? "green" : "red",
                      fontWeight: "bold",
                    }}
                  >
                    {booking.status}
                  </span>
                </td>
                <td>
                  <span
                    style={{
                      color: booking.paymentStatus === "Success" ? "green" : "red",
                      fontWeight: "bold",
                    }}
                  >
                    {booking.paymentStatus}
                  </span>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6">No bookings found.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ViewBookings;
