import React from "react";

const ManageCustomers = () => {
  const customers = [
    { id: 10101, name: "King", email: "King@gmail.com", mobile: "123654789", status: "Active" },
    { id: 10101, name: "King", email: "King@gmail.com", mobile: "123654789", status: "Inactive" },
  ];

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h2>Manage Customers</h2>
      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
        <thead>
          <tr style={{ backgroundColor: "#003366", color: "white" }}>
            <th style={thStyle}>Customer Id</th>
            <th style={thStyle}>Customer Name</th>
            <th style={thStyle}>Email</th>
            <th style={thStyle}>Mobile Number</th>
            <th style={thStyle}>Status</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((customer, index) => (
            <tr key={index} style={{ backgroundColor: index % 2 === 0 ? "#f9f9f9" : "white" }}>
              <td style={tdStyle}>{customer.id}</td>
              <td style={tdStyle}>{customer.name}</td>
              <td style={tdStyle}>{customer.email}</td>
              <td style={tdStyle}>{customer.mobile}</td>
              <td style={tdStyle}>
                <span
                  style={{
                    padding: "5px 10px",
                    color: "white",
                    borderRadius: "5px",
                    backgroundColor: customer.status === "Active" ? "green" : "red",
                  }}
                >
                  {customer.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const thStyle = {
  padding: "10px",
  border: "1px solid #ccc",
  textAlign: "left",
};

const tdStyle = {
  padding: "10px",
  border: "1px solid #ccc",
};

export default ManageCustomers;
