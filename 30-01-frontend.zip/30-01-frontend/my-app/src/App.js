import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

// Components
import HomePage from "./components/HomePage";
import SignUpPage from "./components/SignUpPage";
import LoginPage from "./components/LoginPage";
import ResetPasswd from './components/ResetPasswd';
import AdminDashboard from "./components/AdminDashboard";
import UserDashboard from "./components/UserDashBoard";
import DeliveryDashboard from "./components/DeliveryDashboard";
import PaymentStatus from "./components/PaymentStatus";
import GasBookingPage from "./components/GasBookingpage";
import OrdersPage from "./components/OrdersPage";
import UpdateProfile from "./components/Updateprofile";

// Admin Dashboard Sub-Components
import ManageCustomers from "./components/ManageCustomers";
import ManageDeliveryStaff from "./components/ManageDeliveryStaff";
import AcceptNewConnections from "./components/AcceptNewConnections";
import ManageGasCylinder from "./components/ManageGasCylinder";
import ViewBookings from "./components/ViewBookings";

// Delivery DashBoard
import Home from "./components/DeliveryDashboard";
import Orders from "./components/Orders";
import Refill from "./components/Refill";

function App() {
  return (
    <Router>
      <div>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<HomePage />} />
          <Route path="/signup" element={<SignUpPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<SignUpPage />} />
          <Route path="/forgetpasswd" element={<ResetPasswd />} />

          {/* Admin Dashboard */}
          <Route path="/admin-dashboard" element={<AdminDashboard />}>
            <Route path="manage-customers" element={<ManageCustomers />} />
            <Route path="manage-delivery-staff" element={<ManageDeliveryStaff />} />
            <Route path="accept-new-connections" element={<AcceptNewConnections />} />
            <Route path="manage-gas-cylinder" element={<ManageGasCylinder />} />
            <Route path="view-bookings" element={<ViewBookings />} />
            <Route path="payment-status" element={<PaymentStatus />} />
          </Route>

          {/* User Dashboard */}
          <Route path="/user-dashboard" element={<UserDashboard />}/>
          <Route path="/bookgascylinder" element={<GasBookingPage />} />
          <Route path="/viewhistroy" element={<OrdersPage />} />
          <Route path="/updateprofile" element={<UpdateProfile />} />
         

          {/* Delivery Dashboard */}
          <Route path="/delivery-dashboard" element={<DeliveryDashboard />}>
            <Route path="orders" element={<Orders />} />
            <Route path="refill" element={<Refill />} />
          </Route>
        </Routes>
      </div>
    </Router>
  );
}

export default App;