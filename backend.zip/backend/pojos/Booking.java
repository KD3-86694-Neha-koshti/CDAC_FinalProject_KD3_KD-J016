package com.blogs.pojos;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="booking")
@NoArgsConstructor
@Getter
@Setter
@ToString(callSuper = true,exclude = {"userID"})

public class Booking extends BaseEntity
{
	
	@ManyToOne
	@JoinColumn(name="user_id",nullable = false)
	private User userID;
	
//	@OneToMany(mappedBy = "bookId",cascade = CascadeType.ALL,orphanRemoval =true)
//	private List<GasDelivery> orderId;
	
	@Column(name="payment_status")
	private String paymentStatus;
	
	@Column(name="Customer_Name")
	private String customerName;
	
	@Enumerated(EnumType.STRING)
	private Status status;
	
	@Enumerated(EnumType.STRING)
	@Column(name="cylinder_type")
	private CylinderType cylinderType;
	
	
	public enum Status
	{
		PENDING,CONFIRM,DELIVERED
	}
	public enum CylinderType
	{
		DOMESTIC,COMMERCIAL
	}
	public Booking(User userID, String paymentStatus, Status status,
			CylinderType cylinderType) {
		super();
		this.userID = userID;
		//this.orderId = orderId;
		this.paymentStatus = paymentStatus;
		this.status = status;
		this.cylinderType = cylinderType;
	}
	
}
