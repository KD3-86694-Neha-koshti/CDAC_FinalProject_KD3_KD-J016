package com.blogs.dto;
import com.blogs.pojos.Booking.CylinderType;
import com.blogs.pojos.Booking.Status;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookingRespDto {
	
	    private Long id;
	    private Long userID;
	    private String customerName;  
	    private String paymentStatus;
	    private Status status;
	    private CylinderType cylinderType;
}
