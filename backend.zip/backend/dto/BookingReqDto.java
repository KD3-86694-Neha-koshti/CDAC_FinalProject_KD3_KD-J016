package com.blogs.dto;
import com.blogs.pojos.Booking.CylinderType;
import com.blogs.pojos.Booking.Status;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BookingReqDto {
    private Long userID;
    private String customerName; // ✅ New Field
    private String paymentStatus; // ✅ Payment Method as String
    private Status status;
    private CylinderType cylinderType;
}
