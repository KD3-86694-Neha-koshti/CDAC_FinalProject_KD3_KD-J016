package com.blogs.dto;

import com.blogs.pojos.User.Status;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserStatusUpdateDto {
    private Status status;  
}
