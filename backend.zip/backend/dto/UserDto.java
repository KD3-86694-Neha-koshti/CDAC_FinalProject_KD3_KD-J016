package com.blogs.dto;

import com.blogs.pojos.User.Status;
import com.blogs.pojos.User.UserRole;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UserDto extends BaseDto{
	
	private String fullName;
	private String email;
	private String password;	
	private String address;
	private UserRole role;
	private Long mobileNo;
	private Status status;
	
}
